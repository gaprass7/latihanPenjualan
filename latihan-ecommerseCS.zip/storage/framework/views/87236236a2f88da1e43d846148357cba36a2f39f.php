

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <img src="<?php echo e(url('storage/'.$row->image)); ?>" alt="<?php echo e($row->name); ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
                        <div class="card-body">
                            <h5 class="card-title text-center fw-bold mb-3" style="color: #333;"><?php echo e($row->name); ?></h5>
                            <p class="card-text" style="color: #888;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores fugit assumenda expedita, odit soluta tempora repudiandae! Sint quisquam quas pariatur!</p>
                            <div class="d-flex justify-content-center gap-2">
                                
                                <?php if(Auth::check() && Auth::user()->is_admin): ?>
                                    <form action="<?php echo e(route('delete', $row)); ?>" method="post">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Hapus Produk</button>
                                    </form>
                                <?php endif; ?>
                                <form action="<?php echo e(route('show', $row)); ?>" method="get">
                                    <button type="submit" class="btn btn-primary">Detail Produk</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\php1\latihan-ecommerseCS\resources\views/product/index.blade.php ENDPATH**/ ?>