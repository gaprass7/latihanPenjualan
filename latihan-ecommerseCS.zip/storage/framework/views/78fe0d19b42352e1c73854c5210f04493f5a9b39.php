

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-3">Order ID <?php echo e($order->id); ?></h5>
                            <div class="status">
                                <?php if($order->is_paid): ?>
                                    <span class="badge bg-success">Paid</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Unpaid</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <h6 class="card-subtitle mb-2 text-muted">By <?php echo e($order->user->name); ?></h6>

                        <hr>
                        <?php
                            $total_price = 0;
                        ?>
                        <?php $__currentLoopData = $order->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between">
                                <p><?php echo e($transaction->product->name); ?> - <?php echo e($transaction->amount); ?> pcs</p>
                                <p class="fw-bold">Rp <?php echo e(number_format($transaction->product->price * $transaction->amount, 0, ',', '.')); ?></p>
                            </div>
                            <?php
                                $total_price += $transaction->product->price * $transaction->amount;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <p class="fw-bold">Total Price:</p>
                            <p class="fw-bold">Rp <?php echo e(number_format($total_price, 0, ',', '.')); ?></p>
                        </div>
                        <hr>

                        <?php if(!$order->is_paid && $order->payment_receipt == null && !Auth::user()->is_admin): ?>
                            <form action="<?php echo e(route('submit_payment', $order)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="payment_receipt" class="form-label">Upload your payment receipt</label>
                                    <input type="file" name="payment_receipt" id="payment_receipt" class="form-control">
                                </div>
                                <button type="submit" class="btn btn-primary mt-3">Submit payment</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\php1\latihan-ecommerseCS\resources\views/product/order/detail.blade.php ENDPATH**/ ?>