

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body p-4">
                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('order/' . $order->id)); ?>" class="text-decoration-none text-dark">
                                <div class="mb-4">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <h5 class="mb-0">Order ID: <?php echo e($order->id); ?></h5>
                                        <div class="status">
                                            <?php if($order->is_paid): ?>
                                                <span class="badge bg-success">Paid</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Unpaid</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <p class="mb-3">User: <?php echo e($order->user->name); ?></p>
                                    <p class="mb-3">Tanggal Order: <?php echo e($order->created_at); ?></p>

                                    <?php if(!$order->is_paid): ?>
                                        <div class="d-flex justify-content-end">
                                            <?php if($order->payment_receipt): ?>
                                                <a href="<?php echo e(url('storage/' . $order->payment_receipt)); ?>" class="btn btn-outline-primary me-2">Lihat Bukti Pembayaran</a>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->is_admin): ?>
                                                <form action="<?php echo e(route('confirm_payment', $order)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary">Confirm</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <hr>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\php1\latihan-ecommerseCS\resources\views/product/order/index.blade.php ENDPATH**/ ?>