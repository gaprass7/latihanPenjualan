

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3>Keranjang Belanja</h3>
                    </div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php
                            $total_price = 0;
                        ?>

                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <img src="<?php echo e(url('storage/' . $cart->product->image)); ?>" alt="<?php echo e($cart->product->name); ?>" height="100px" class="img-thumbnail">
                                </div>
                                <div class="col-md-6">
                                    <h5><?php echo e($cart->product->name); ?></h5>
                                    <p class="text-muted">Harga: Rp. <?php echo e(number_format($cart->product->price, 0, ',', '.')); ?></p>
                                    <form action="<?php echo e(route('update_cart', $cart)); ?>" method="POST" class="mb-2">
                                        <?php echo method_field('patch'); ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="input-group">
                                            <input type="number" name="amount" class="form-control" value="<?php echo e($cart->amount); ?>">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </form>
                                    <form action="<?php echo e(route('delete_cart', $cart)); ?>" method="POST">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Remove</button>
                                    </form>
                                </div>
                                <div class="col-md-3 text-end">
                                    <p class="fw-bold">Total: Rp. <?php echo e(number_format($cart->product->price * $cart->amount, 0, ',', '.')); ?></p>
                                </div>
                                <?php
                                    $total_price += $cart->product->price * $cart->amount;
                                ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr>

                        <div class="text-end">
                            <p class="fw-bold">Total Harga: Rp. <?php echo e(number_format($total_price, 0, ',', '.')); ?></p>
                            <form action="<?php echo e(route('checkout')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary" <?php if($carts->isEmpty()): ?> disabled <?php endif; ?>>Checkout</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\php1\latihan-ecommerseCS\resources\views/product/cart/detail.blade.php ENDPATH**/ ?>